class IssueUsers < ActiveRecord::Base
end
