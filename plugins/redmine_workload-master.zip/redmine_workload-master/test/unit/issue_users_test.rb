require File.dirname(__FILE__) + '/../test_helper'

class IssueUsersTest < Test::Unit::TestCase
  fixtures :issue_users

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
