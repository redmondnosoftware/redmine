require File.dirname(__FILE__) + '/../test_helper'

class WorklistTest < Test::Unit::TestCase
  fixtures :worklists

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
